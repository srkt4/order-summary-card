## Overview

This is a mini project to experiment and train with HTML/CSS.

## Screenshot

url(https://i.goopics.net/P5lK0.png)

## Built with

- Semantic HTML5 markup
- CSS custom properties
- Flexbox
- Mobile-first workflow


## What I learned

- using media queries
- hover
- box-shadow


